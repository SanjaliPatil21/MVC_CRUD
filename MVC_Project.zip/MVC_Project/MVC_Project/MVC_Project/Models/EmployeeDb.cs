﻿using System.Data;
using Microsoft.Data.SqlClient;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace MVC_Project.Models
{
    public class EmployeeDb
    {
        SqlConnection conn;
        string constr = "Server=LAPTOP-2QFANLP1\\SQLEXPRESS;Initial Catalog = EMPLMS; Integrated Security = True;TrustServerCertificate=True;";

        public IEnumerable<Employee> GetAllEmp()
        {
            
            List<Employee> list = new List<Employee>();
            using (conn = new SqlConnection(constr))
            {
                
                conn.Open();
                SqlCommand cmd = new SqlCommand("sp_showemp", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Employee e = new Employee();
                    e.Eid = (Int64)dr["Empid"];
                    e.Ename = dr["ename"].ToString();
                    e.Email = dr["email"].ToString();
                    e.Department = dr["department"].ToString();
                    e.Designation = dr["designation"].ToString();
                    e.Doj = dr["Doj"].ToString();
                    e.Dob = dr["dob"].ToString();
                    e.EmpType = dr["emptype"].ToString();
                    e.Gender = dr["Gender"].ToString();
                    e.Salary = (decimal)dr["salary"];

                    list.Add(e);
                }
                
                return list;
                conn.Close();
               
            }
        }


        public void AddEmp(Employee e)
        {
            using (conn = new SqlConnection(constr))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("sp_InsertEmp", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "sp_InsertEmp";
                cmd.Parameters.AddWithValue("@ename", e.Ename);
                cmd.Parameters.AddWithValue("@Email", e.Email);
                cmd.Parameters.AddWithValue("@Department", e.Department);
                cmd.Parameters.AddWithValue("@Designation", e.Designation);
                cmd.Parameters.AddWithValue("@DOJ", e.Doj);
                cmd.Parameters.AddWithValue("@DOB", e.Dob);
                cmd.Parameters.AddWithValue("@EmpType", e.EmpType);
                cmd.Parameters.AddWithValue("@Gender", e.Gender);
                cmd.Parameters.AddWithValue("@salary", e.Salary);

                int s = cmd.ExecuteNonQuery();
                conn.Close();
            }
        }

        public void EditEmp(Employee e)
        {
            using (conn = new SqlConnection(constr))
            {
                SqlCommand cmd = new SqlCommand("sp_UpdateEmp", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Empid", e.Eid);
                cmd.Parameters.AddWithValue("@ename", e.Ename);
                cmd.Parameters.AddWithValue("@Email", e.Email);
                cmd.Parameters.AddWithValue("@Department", e.Department);
                cmd.Parameters.AddWithValue("@Designation", e.Designation);
                cmd.Parameters.AddWithValue("@DOJ", e.Doj);
                cmd.Parameters.AddWithValue("@DOB", e.Dob);
                cmd.Parameters.AddWithValue("@EmpType", e.EmpType);
                cmd.Parameters.AddWithValue("@Gender", e.Gender);
                cmd.Parameters.AddWithValue("@salary", e.Salary);
                int s = cmd.ExecuteNonQuery();

                conn.Close();

            }
        }

        public void DeleteEmp(int? id)
        {
            using (conn = new SqlConnection(constr))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("sp_DeleteEmp", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Empid", id);
                int s = cmd.ExecuteNonQuery();
                conn.Close();

            }
        }

        public Employee GetEmployeeData(int? id)
        {
            
            Employee e = new Employee();
            using (conn = new SqlConnection(constr))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("sp_showemp", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    e.Eid = (Int64)dr["Empid"];
                    e.Ename = dr["ename"].ToString();
                    e.Email = dr["email"].ToString();
                    e.Department = dr["department"].ToString();
                    e.Designation = dr["designation"].ToString();
                    e.Doj = dr["Doj"].ToString();
                    e.Dob = dr["dob"].ToString();
                    e.EmpType = dr["emptype"].ToString();
                    e.Gender = dr["Gender"].ToString();
                    e.Salary = (decimal)dr["salary"];


                }

                conn.Close();
                return e;

            }
        }
    }
}
