﻿namespace MVC_Project.Models
{
    public class EmpType
    {
        public enum EmployeeType
        {
            FullTime,
            PartTime,
            Contractor,
            Intern
        }

        public enum Department
        {
            IT,
            HR,
            Finance,
            Marketing
        }

    }
}
