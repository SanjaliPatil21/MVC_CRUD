﻿using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using static MVC_Project.Models.EmpType;

namespace MVC_Project.Models
{
    public class Employee
    {
        [Key]
        public Int64 Eid { get; set; }

        [Required(ErrorMessage = "Name cannot be blank")]
        public string Ename { get; set; }
        [EmailAddress(ErrorMessage = "Enter Valid Email id")]
        public string Email { get; set; }
        [Required]
        public string Department { get; set; }
        [Required]
        public string Designation { get; set; }

        [DataType(DataType.Date, ErrorMessage = "Doj Must be date")]
        public string Doj { get; set; }

        [DataType(DataType.Date, ErrorMessage = "Dob Must be date")]
        public string Dob { get; set; }
        public string EmpType { get; set; }
        public string Gender { get; set; }
        [DataType(DataType.Currency,ErrorMessage ="Enter correctdata")]
        [Range(0,double.MaxValue,ErrorMessage ="Enter salary in range")]
        public decimal Salary { get; set; }


    }
}
