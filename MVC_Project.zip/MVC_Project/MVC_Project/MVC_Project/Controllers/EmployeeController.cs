﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MVC_Project.Models;

namespace MVC_Project.Controllers
{
    public class EmployeeController : Controller
    {
        EmployeeDb db = new EmployeeDb();
        [BindProperty]
        public List<Employee> Employees { get; set; }

        // GET: EmployeeController
        public ActionResult Index()
        {
            var empList = db.GetAllEmp();

            // Get unique departments and emp types for dropdowns
            ViewBag.Departments = empList.Select(e => e.Department).Distinct().ToList();
            ViewBag.EmpTypes = empList.Select(e => e.EmpType).Distinct().ToList();

            return View(empList);
            return View(db.GetAllEmp().ToList());
        }

        // GET: EmployeeController/Details/5
        public ActionResult Details(int id)
        {
            return View(db.GetEmployeeData(id));
        }
        [HttpGet]
        // GET: EmployeeController/Create
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(Employee emp)
        {
            if (ModelState.IsValid)
            {
                db.AddEmp(emp);
                return RedirectToAction("Index");
                
            }
            return View();
            
        }
             



        // GET: Emp
   
        public ActionResult Edit(int? id)
        {
            Employee emp = db.GetEmployeeData(id);
            return View(emp);
        }

        // POST: EmployeeController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, Employee emp)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    db.EditEmp(emp);
                }
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: EmployeeController/Delete/5
        public ActionResult Delete(int id)
        {
            return View(db.GetEmployeeData(id));
        }

        // POST: EmployeeController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, Employee emp)
        {
            try
            {
                db.DeleteEmp(id);
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        public ActionResult FilterEmp(string name,string dept,string etype)
        {
            var empdata = db.GetAllEmp().AsQueryable(); // already queried

            if (!string.IsNullOrEmpty(name))
            {
                empdata = empdata.Where(e => e.Ename == name);
            }

            if (!string.IsNullOrEmpty(dept))
            {
                empdata = empdata.Where(e => e.Department == dept);
            }

            if (!string.IsNullOrEmpty(etype))
            {
                empdata = empdata.Where(e => e.EmpType == etype);
            }
            ViewBag.Departments = db.GetAllEmp().Select(e => e.Department).Distinct().ToList();
            ViewBag.EmpTypes = db.GetAllEmp().Select(e => e.EmpType).Distinct().ToList();

            return View("Index", empdata.ToList());
            //return View(empdata.ToList());
        }
    }
}
