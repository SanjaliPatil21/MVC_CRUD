
create table empManage(Empid bigint primary key identity(1,1) ,EName varchar(20) Not null,Email varchar(50),Department varchar(20),Designation varchar(20),DOJ date,DOB date,EmpType varchar(20),Gender varchar(10),Salary decimal)

select *from empManage

INSERT INTO empManage (EName, Email, Department, Designation, DOJ, DOB, EmpType, Gender, Salary)
VALUES 
('Amit Sharma', 'amit.sharma@example.com', 'IT', 'Developer', '2022-06-15', '1995-08-10', 'Full-Time', 'Male', 55000.00),

('Priya Singh', 'priya.singh@example.com', 'HR', 'HR Manager', '2021-04-01', '1990-12-25', 'Full-Time', 'Female', 65000.00),

('Ravi Kumar', 'ravi.kumar@example.com', 'Finance', 'Accountant', '2023-01-10', '1992-07-19', 'Part-Time', 'Male', 40000.00),

('Neha Verma', 'neha.verma@example.com', 'IT', 'Tester', '2023-09-20', '1996-03-11', 'Full-Time', 'Female', 48000.00),

('Arjun Mehta', 'arjun.mehta@example.com', 'Marketing', 'Executive', '2020-11-30', '1988-02-05', 'Contract', 'Male', 52000.00);


--create employee show store procedure
create procedure sp_showemp
as
begin
select *from empManage
end;

exec sp_showemp

--create procedure for Insert into emp

CREATE PROCEDURE sp_InsertEmp(@EName VARCHAR(20),@Email VARCHAR(20), @Department VARCHAR(20),@Designation VARCHAR(20), @DOJ DATE,@DOB DATE,@EmpType VARCHAR(20),@Gender VARCHAR(10),@Salary decimal)
AS
BEGIN
INSERT INTO empManage (EName, Email, Department, Designation, DOJ, DOB, EmpType, Gender, Salary)
VALUES (@EName, @Email, @Department, @Designation, @DOJ, @DOB, @EmpType, @Gender, @Salary);
END;

--create procedure for Update into emp
CREATE PROCEDURE sp_UpdateEmp(@Empid bigint,@EName VARCHAR(20),@Email VARCHAR(20),@Department VARCHAR(20),@Designation VARCHAR(20),@DOJ DATE,@DOB DATE, @EmpType VARCHAR(20),@Gender VARCHAR(10),@Salary decimal)
AS
BEGIN
UPDATE empManage SET EName = @EName,Email = @Email,Department = @Department,Designation = @Designation,DOJ = @DOJ,DOB = @DOB,EmpType = @EmpType,Gender = @Gender,Salary = @Salary WHERE Empid = @Empid;
END;

--create store procedure for delete Emp

CREATE PROCEDURE sp_DeleteEmp(@Empid bigint)
AS
BEGIN
DELETE FROM empManage WHERE Empid = @Empid;
END;


--Show example
EXEC sp_showemp


-- Insert example
EXEC sp_InsertEmp 'Rohit Roy', 'rohit.roy@example.com', 'Sales', 'Sales Executive','2024-04-01', '1993-11-12', 'Full-Time', 'Male', 47000;

-- Update example
EXEC sp_UpdateEmp  6, 'Rohit Roy', 'rohit.roy@company.com', 'Sales', 'Manager','2024-04-01', '1993-11-12', 'Full-Time', 'Male', 60000;

-- Delete example
EXEC sp_DeleteEmp 6;




EXEC sp_InsertEmp 'Amit Sharma', 'amit.sharma@example.com', 'Marketing', 'Marketing Manager', '2023-03-15', '1988-07-23', 'Full-Time', 'Male', 55000;
EXEC sp_InsertEmp 'Priya Mehta', 'priya.mehta@example.com', 'HR', 'HR Executive', '2022-06-10', '1990-01-17', 'Full-Time', 'Female', 43000;
EXEC sp_InsertEmp 'Karan Patel', 'karan.patel@example.com', 'IT', 'Software Engineer', '2021-09-01', '1992-05-30', 'Full-Time', 'Male', 60000;
EXEC sp_InsertEmp 'Sneha Reddy', 'sneha.reddy@example.com', 'Finance', 'Accountant', '2020-11-05', '1991-03-12', 'Part-Time', 'Female', 35000;
EXEC sp_InsertEmp 'Rahul Verma', 'rahul.verma@example.com', 'Support', 'Customer Support Executive', '2024-01-20', '1995-08-08', 'Full-Time', 'Male', 32000;
EXEC sp_InsertEmp 'Neha Singh', 'neha.singh@example.com', 'IT', 'System Analyst', '2023-07-18', '1989-10-14', 'Full-Time', 'Female', 58000;
EXEC sp_InsertEmp 'Ankit Joshi', 'ankit.joshi@example.com', 'Sales', 'Sales Representative', '2023-02-25', '1994-06-03', 'Contract', 'Male', 40000;
EXEC sp_InsertEmp 'Divya Nair', 'divya.nair@example.com', 'HR', 'Recruiter', '2022-10-12', '1991-12-19', 'Full-Time', 'Female', 45000;
EXEC sp_InsertEmp 'Vikas Dubey', 'vikas.dubey@example.com', 'Logistics', 'Logistics Coordinator', '2021-05-28', '1987-09-11', 'Full-Time', 'Male', 47000;
EXEC sp_InsertEmp 'Ritika Gupta', 'ritika.gupta@example.com', 'Finance', 'Financial Analyst', '2023-08-03', '1990-02-26', 'Full-Time', 'Female', 53000;
